# Gerar o APK do Alarme de Escala — versão offline

Esta versão usa Capacitor para empacotar a interface dentro do APK. Os dados da escala, alarmes, exceções, histórico e músicas ficam no aparelho. A internet não é necessária para o uso normal do app.

## No PC

1. Instale **Node.js 20+**, **Android Studio** e **JDK 21**.
2. Extraia este ZIP.
3. Abra o Prompt de Comando/PowerShell na pasta do projeto.
4. Rode:

```bash
npm install
npm run android:release
```

Na primeira execução o script cria a pasta `android/`, adiciona as permissões necessárias, instala o som padrão e prepara o ícone da notificação.

O APK ficará em:

```text
android/app/build/outputs/apk/release/app-release.apk
```

## Abrir no Android Studio

Se quiser abrir o projeto:

```bash
npx cap open android
```

Depois, no Android Studio, use **Build > Generate App Bundles or APKs > Generate APKs**.

## Importante sobre os alarmes

- O APK agenda os próximos alarmes diretamente pelo Android.
- O agendamento usa alarmes exatos e `allowWhileIdle`.
- A permissão de notificações precisa estar liberada.
- Em aparelhos com economia agressiva de bateria, deixe o app como **Sem restrições**.
- O Android pode aplicar regras próprias de fabricante/versão. Por isso, faça um teste com tela bloqueada e internet desligada antes de confiar no alarme para um horário de trabalho.

## Som

O APK inclui `public/alarme.wav` como som padrão do sistema de notificações. A música personalizada escolhida pelo usuário continua armazenada localmente para reprodução quando o aplicativo estiver ativo; transformar qualquer música escolhida em som de canal de notificação nativo exige uma etapa Android específica e não é feito pelo navegador.

## Sem internet

Depois que o APK estiver instalado e os alarmes estiverem configurados, o app não precisa acessar servidor para calcular a escala, mostrar o calendário, salvar dados ou programar os alarmes.
