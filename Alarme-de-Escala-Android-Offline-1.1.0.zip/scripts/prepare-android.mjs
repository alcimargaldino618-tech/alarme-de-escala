import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const root = process.cwd();
const androidDir = path.join(root, 'android');

function run(cmd, args) {
  const result = spawnSync(cmd, args, { stdio: 'inherit', shell: process.platform === 'win32' });
  if (result.status !== 0) process.exit(result.status ?? 1);
}

if (!fs.existsSync(androidDir)) {
  console.log('Criando projeto Android do Capacitor...');
  run(process.platform === 'win32' ? 'npx.cmd' : 'npx', ['cap', 'add', 'android']);
}

const manifest = path.join(androidDir, 'app', 'src', 'main', 'AndroidManifest.xml');
let xml = fs.readFileSync(manifest, 'utf8');
const permissions = [
  'android.permission.POST_NOTIFICATIONS',
  'android.permission.SCHEDULE_EXACT_ALARM',
  'android.permission.USE_EXACT_ALARM',
  'android.permission.VIBRATE',
  'android.permission.WAKE_LOCK',
];
for (const permission of permissions) {
  const line = `    <uses-permission android:name="${permission}" />`;
  if (!xml.includes(`android:name="${permission}"`)) {
    xml = xml.replace(/(<manifest[^>]*>)/, `$1\n${line}`);
  }
}
if (!xml.includes('RECEIVE_BOOT_COMPLETED')) {
  xml = xml.replace(/(<manifest[^>]*>)/, '$1\n    <!-- Reservado para futuras rotinas de reprogramação no boot. -->');
}
fs.writeFileSync(manifest, xml);

const rawDir = path.join(androidDir, 'app', 'src', 'main', 'res', 'raw');
const drawableDir = path.join(androidDir, 'app', 'src', 'main', 'res', 'drawable');
fs.mkdirSync(rawDir, { recursive: true });
fs.mkdirSync(drawableDir, { recursive: true });

const sourceSound = path.join(root, 'public', 'alarme.wav');
const targetSound = path.join(rawDir, 'alarme.wav');
if (fs.existsSync(sourceSound)) fs.copyFileSync(sourceSound, targetSound);

const icon = `<?xml version="1.0" encoding="utf-8"?>\n<vector xmlns:android="http://schemas.android.com/apk/res/android"\n    android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24">\n    <path android:fillColor="#FFFFFFFF" android:pathData="M12,22a2.4,2.4 0,0 0,2.35 -2h-4.7A2.4,2.4 0,0 0,12 22zM18,16v-5c0,-3.07 -1.63,-5.64 -4.5,-6.32V4a1.5,1.5 0,0 0,-3 0v0.68C7.63,5.36 6,7.93 6,11v5l-2,2v1h16v-1z"/>\n</vector>\n`;
fs.writeFileSync(path.join(drawableDir, 'ic_stat_alarm.xml'), icon);

console.log('Projeto Android preparado.');
console.log('Agora execute: npm run android:build && npm run android:sync && npm run android:apk');
