# Alarme de Escala — Android offline

O projeto é uma aplicação React/TanStack empacotada com Capacitor. O conteúdo web é colocado dentro do APK, e os dados da aplicação ficam em IndexedDB local.

## Requisitos

- Node.js 20+
- Android Studio com Android SDK
- JDK 21

## Gerar APK

```bash
npm install
npm run android:release
```

O script executa o build web, cria/prepara o projeto Android, sincroniza o Capacitor e gera o APK de release.

Saída:

```text
android/app/build/outputs/apk/release/app-release.apk
```

## Alarmes

No APK, os próximos horários válidos da escala são programados usando `@capacitor/local-notifications`, com `allowWhileIdle` e alarme exato obrigatório. O app não usa internet para disparar o horário.

O aplicativo verifica a permissão de alarmes exatos. Se ela não estiver liberada, não agenda uma versão inexata silenciosamente: o usuário deve liberar a permissão na tela de Permissões do aplicativo.

## Limitação importante

O Android pode cancelar alarmes agendados quando o aparelho é reiniciado. Esta versão recalcula e agenda novamente quando o aplicativo é aberto/retoma, mas não deve ser descrita como garantia de reagendamento automático sem abrir o app após um reboot. Para garantia de reboot sem abrir a interface, é necessário adicionar um componente nativo Android (BootReceiver + armazenamento nativo da agenda).

## Som

`public/alarme.wav` é copiado para `res/raw` durante `npm run android:prepare` e usado pelo canal de notificação nativo. O ícone `ic_stat_alarm` também é criado automaticamente.
